# LearnHub — Free Online Teaching Website

This is a ready-to-use front-end teaching website made with:
- HTML
- CSS
- JavaScript

## Run it
1. Keep `index.html`, `style.css`, and `script.js` in the same folder.
2. Open `index.html` in a browser.

## Customize
- Change "LearnHub" to your teaching brand in `index.html`.
- Replace "Your Teacher Name", email and WhatsApp number.
- Replace sample course descriptions.
- Add your own PDF/Google Drive links in the Notes section.
- Add YouTube/Google Meet links to course buttons.
- Edit colors in `style.css`.

## Important
The login, database, real student accounts, payments, and private video access are NOT included in this free front-end template. They require a backend/service when you are ready for them.

## Free publishing
You can publish this static site using GitHub Pages or another free static hosting service.
