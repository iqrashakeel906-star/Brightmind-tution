const nav = document.getElementById("nav");
document.querySelector(".menu-btn").addEventListener("click", () => nav.classList.toggle("open"));

function filterCourses(cat, btn){
  document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));
  btn.classList.add("active");
  document.querySelectorAll(".course-card").forEach(card=>{
    card.style.display = (cat==="all" || card.dataset.cat===cat) ? "" : "none";
  });
}

function openCourse(name){
  showModal(`<h2>${name}</h2><p>This is a ready-to-customize course card. Add your video links, lesson list, notes and assignments here.</p><a class="btn primary" href="#contact" onclick="closeModal()">Join this course</a>`);
}
function downloadNotice(name){
  showModal(`<h2>${name}</h2><p>Add your own PDF link in <b>index.html</b> to make this button open or download your study material.</p>`);
}
function showJoin(){
  showModal(`<h2>Welcome to LearnHub 🎓</h2><p>Your free student registration area is ready to customize. For a real login system, connect this front-end to a backend/database later.</p><a class="btn primary" href="#contact" onclick="closeModal()">Contact Teacher</a>`);
}
function showModal(content){
  document.getElementById("modalContent").innerHTML = content;
  document.getElementById("modal").style.display = "grid";
}
function closeModal(){ document.getElementById("modal").style.display="none"; }

function answer(choice){
  const result=document.getElementById("quiz-result");
  if(choice===1){
    result.textContent="✅ Correct! Mitochondria are known as the powerhouse of the cell.";
  }else{
    result.textContent="❌ Not quite. Try again — think about the organelle that produces most cellular ATP.";
  }
}
function resetQuiz(){
  document.getElementById("quiz-result").textContent="";
}
function sendMessage(e){
  e.preventDefault();
  const name=document.getElementById("name").value.trim();
  document.getElementById("form-msg").textContent=`Thanks, ${name}! Your message is ready to be connected to your email/WhatsApp service.`;
  e.target.reset();
}
